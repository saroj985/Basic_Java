
public class Nothing {

	public static void main(String[] args) {

//		
//		int size = 7; // Size of the square
//
//        for (int i = 1; i <= size; i++) {
//            for (int j = 1; j <= size; j++) {
//                // Check if on the borders or within the pyramid
//                if (i == 1 || i == size || j == 1 || j == size || 
//                    j == (size + 1) / 2 - i + 1 || j == (size + 1) / 2 + i - 1) {
//                    System.out.print("* ");
//                } else {
//                    System.out.print("  ");
//                }
//            }
//            System.out.println();
//        }

//		String[] [] cars = {{"Toyota", "Honda", "Tesla"}, {"VW", "GM"}};
//		
//		for(String [] row : cars) {
//			for(String car : row) {
//				System.out.print("["+car+"]");
//			}
//			System.out.println("\n");
//		}
//		

//		int [][] numbers = {{1,2,3},{1,2,3}};
//		
//		for(int[] row : numbers) {
//			for (int num : row) {
//				System.out.print(num);
//			}
//				System.out.println();	
//		
//		}
//		

		
		//Find who you are? 
		
//		int age = 12;
//		
//		if (age <= 1) {
//			System.out.println("you are a newborn");
//		} else if (age > 1 && age <= 3) {
//			System.out.println("You are an infant");
//		} else if (age > 3 && age < 13) {
//			System.out.println("You are a child");
//		} else if (age >= 13 && age <= 19 ) {
//			System.out.println("You are a teenager");
//		} else if (age > 20 && age < 60) {
//			System.out.println("You are an adult");
//		} else if (age > 60) {
//			System.out.println("You are an old");
//		}		
//		
		
//	make a switch case with char types like 'a' and float type.
		
	char value = 'a';
	
	switch(value) {
		case 'a':
			System.out.println("The value of char type is => " + value);
			break;
		default:
			System.out.println("Sorry, no value found.");		break;
		}
		
		
		
		
	float num = 1.1f;
	
	switch(num) {
	case num:
		System.out.println("The value of float is => " + num);
		break;
	default:
		System.out.println("Sorry, no value is found. Error: Cannot switch on a value of type float.");
		System.out.println("Only convertible int values, strings or enum variables are permitted");
	}
	
	
//	int sarojMoney = 8;
//
//	if (sarojMoney > 9) {
//		System.out.println("You have more money.");
//	} else {
//		System.out.println("You have less money");
//		
//		
//	}
		
	
	String [] cars = {"Toyota", "Honda", "Subaru", "Old car", "New Car", "Nice car", "bad car"};
//	System.out.println(cars[0]);
//	System.out.println(cars[1]);
//	System.out.println(cars[2]);
	
//	int [] numbers = {1,2,5,8,4,3};
//	System.out.println(numbers[3]);
	
//	for (String x : cars) {
//		System.out.println(  "I like cars       "              );
//	}
	
	
	
	
	
	
	
	int [] num = {1,2,3,788777,8,5,6,7,459988};
	
	
	System.out.println(num[7]);

	
	
//	for (int i = 1; i < num.length; i++) {
//		System.out.println("Number " + i);
//	}

	
	
	
	
	
	
	
	
	
	
	
		
	}
}

