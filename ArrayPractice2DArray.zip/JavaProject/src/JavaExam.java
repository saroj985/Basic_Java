
public class JavaExam {

	public static void main(String[] args) {
		
//		        int size = 7; // Size of the square
//
//		        for (int i = 1; i <= size; i++) {
//		            for (int j = 1; j <= size; j++) {
//		                // Check if on the borders or within the pyramid
//		                if (i == 1 || i == size || j == 1 || j == size || 
//		                    j == (size + 1) / 2 - i + 1 || j == (size + 1) / 2 + i - 1) {
//		                    System.out.print("* ");
//		                } else {
//		                    System.out.print("  ");
//		                }
//		            }
//		            System.out.println();
//		        }
		
		int rows = 10;
		int columns = 10;
		

        for (int i = 1; i <= rows; i++) {
            for (int j = 1; j <= columns; j++) {
                // Print '*' for the border
                if (i == 1 || i == rows || j == 1 || j == columns) {
                    System.out.print("*");
                } else {
            		}
                	
                }
            }
            System.out.println();  // Move to the next line after each row
        }
		
		
		    }
		
	}


