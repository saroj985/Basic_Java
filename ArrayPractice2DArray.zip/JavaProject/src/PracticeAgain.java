
public class PracticeAgain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a = 3;
		int b = 2;
		float c = (float)3 / 2;
		
		
//		int does not take decimal
//		float takes decimal
		
		
		
		System.out.println("The value of c => " + c);

//		System.out.println("The value of b => " + b);
		
		

	}

}
