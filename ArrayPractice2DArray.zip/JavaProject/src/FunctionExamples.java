
//public class FunctionExamples {
//
//	public static void main(String[] args) {
//		System.out.println("Hello");
//		FunctionExamples a = new FunctionExamples();
//		a.getAge();
//	}
//	//make a function
//	public void getAge() {
//		System.out.println("Saroj");
//	}
//	
//
//}

//public class FunctionExamples {
//	public static void main(String[] args) {
//		System.out.println("Hello");
//		getAge();
//	}
//	//make a function
//	public static void getAge() {
//		System.out.println("Saroj");
//	}
//}

//public class FunctionExamples {
//	public static void main(String[] args) {
//		int age = 10;
//		getAgeInDays(age);
//
//	}
//
//	public static void getAgeInDays(int age) {
//		age = age * 365; //convert age to days
//		System.out.println("You are " + age + " days old.");
//
//	}
//}

public class FunctionExamples {
	public static void main(String[] args) {
		System.out.println("*************************");
		System.out.println("Interest Rate Calculator");
		System.out.println("*************************");
		
		int value = 9000;
		int interest = 5;
		int year = 1;
		totalInterestValue(value, interest, year);
	}	
	public static void totalInterestValue(int value, int interest, int year) {
		int totalInterest = value * interest * year /100;
		System.out.println("\nThe total interest for $" + value + " will be: " + "$" + totalInterest);
	}
}


