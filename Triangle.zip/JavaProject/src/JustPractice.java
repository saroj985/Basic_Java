
public class JustPractice {

	public static void main(String[] args) {
		String[][] cars = new String[2][3];
		cars[0][0] = "Toyota";
		cars[0][1] = "Honda";
		cars[0][2] = "Volkswagen";
		cars[1][0] = "Subaru";
		cars[1][1] = "Mazda";
		cars[1][2] = "Tesla";

//		System.out.println(cars[0][2]);
//		System.out.println(cars.length);

//		for(int i = 0; i < cars.length; i ++) {
//			for (int j = 0; j < cars[i].length; j++ ) {
//				System.out.print("[  "+cars[i][j]+"  ]");
//			}
//			System.out.println("\n=======================================");
//		}
//		
//		for (int i = 1; i <=10; i++) {
//			for (int j = 1; j <=10; j++) {
//				System.out.println(i +  " * " + j + " = " + i * j );
//			}
//			System.out.println("-----------");
//		}
		
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 30; j++) {
				if (j < 7) {
					System.out.print("*");
				} else {
					System.out.print("=");
				}
			}
			System.out.println();

		}
		for (int i = 0; i < 6; i++) {
			for (int j = 0; j < 30; j++) {
				System.out.print("=");
			}
			System.out.println();
		}
		
	}
}
