//Subarray Sum Equals K
//Problem: Given an array of integers nums and an integer k, return the total number of continuous subarrays whose sum equals to k.
//
//Example:
//
//text
//Copy code
//Input: nums = [1, 1, 1], k = 2
//Output: 2
//Explanation: There are two subarrays [1, 1] and [1, 1] whose sum equals to 2.

public class SubArraySumEqualsToK {

	public static void main(String[] args) {
		int[] nums = {1, 1, 1};
		int k = 2;
		int m = 0;
		for (int i = 0; i < nums.length; i++) {
			for (int j = i + 1; j < nums.length; j++) {
				if (nums[i] + nums[j] == k) {
					m += nums[i]+ nums[j];
					System.out.println(m);
			        System.out.println("Total number of subarrays whose sum equals " + k + ": " + m);

					return;
				}
			}
		}
	}

}
