//Write a program that initializes an integer variable score to 50 and then modifies it based on the following conditions:
//
//If score is less than 60, add 20 to it.
//If score is between 60 and 80, subtract 10.
//If score is greater than 80, multiply it by 2.
//Finally, print the resulting score.


public class Score {
	public static void main(String[] args) {
		int score = 90;
		if(score < 60)
			score += 20;
		else if (score >= 60 && score <= 80)
			score -= 10;
		else if (score > 80)
			score *= 2;
		
		System.out.println("The score is: " + score);
	}

}
