import java.util.Scanner;

public class InputScanner {

	public static void main(String[] args) {
//		int a = 5;
//		int b = --a;  // Pre-decrement: a becomes 4, and b gets assigned the new value 4
//		int c = a--;   //  Post-decrement: c gets the current value of a (4), then a becomes 3
//
//		System.out.println("a = " + a); // Output: a = 3
//		System.out.println("b = " + b); // Output: b = 4
//		System.out.println("c = " + c); // Output: c = 4
//		
//		int a = 2;
//		int b = 3;
//		
//		int c = 4;
//		c *= 4;
//		
//		float d = 5;
//		d /= 2;
//		
//		boolean x = !(a == b);
//		boolean y = c == d;
//		System.out.println(a);
//		System.out.println(b);
//		System.out.println(c);
//		System.out.println(d);
//		System.out.println(x);
//		System.out.println(y);
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Welcome the Registrartion ");
		
		System.out.print("Enter you first name: ");
		String firstName = scanner.nextLine();
		
		System.out.print("Enter your last name: ");
		String lastName = scanner.nextLine();
		
		System.out.print("Enter your age: ");
		int age = scanner.nextInt();
		
		System.out.print("Enter your email: ");
		String email = scanner.next();
		
		System.out.print("Do you agree to the terms and conditions? ");
		boolean terms = scanner.nextBoolean();
		
		
		System.out.println("Registration Details:");
		System.out.println("Name:" + firstName + lastName);
		System.out.println("Age: " + age);
		System.out.println("Email: " + email);
		System.out.println("Agreed to Terms: " + terms);
		
		scanner.close();
		
	}

}
