
public class Car {
	
//	String car;
//	String model;
//	int year;
//	
//	public Car(String carName, String modelName, int yearName) {
//		car = carName;
//		model = modelName;
//		year = yearName;
//		
//	}
//	
//	public void sarojCar() {
//		System.out.println("Saroj car is: " + car + " " + model + " "+ year);
//	}
//	
//	
//	
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		
//		Car myCar = new Car("Toyota", "Matrix", 2005);
//		myCar.sarojCar();
//		
//		
//		
//
//	}

	
	
	String car;
	String model;
	int age;
	String color;
	
	
	
	public Car(String sCar, String sModel, int sAge, String sColor) {
		car = sCar;
		model = sModel;
		age = sAge;
		color = sColor;
	}
	
	public void carOfSabina() {
		System.out.println("Sabina's car is " + car +" " + model +" " + age +" " + color +".");
	}
	
	
	
	public static void main(String[] args) {
		Car sabinaCar = new Car("Volkswagen", "Golf", 2018, "White");
		sabinaCar.carOfSabina();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
