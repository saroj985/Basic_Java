
public class AreaOfSquare {

//	Passing value before object creation
//	
//	public void squareArea() {
//		int area = 10;
//		System.out.println("Area of square is: " + area * area);
//		}
//	
//	
//	public static void main(String[] args) {
//
//		AreaOfSquare square = new AreaOfSquare();
//		square.squareArea();
//		
//	}

//	 ***************************************************************	
//	Passing value after object creation
	
//	int area;
//	
//	public AreaOfSquare(int valueOfArea) {
//		area = valueOfArea * valueOfArea;
//		System.out.println("Area of square is: " + area);
//	}
//	
//	
//	
//	public static void main(String[] args) {
//		AreaOfSquare square = new AreaOfSquare(10);
//	}
//		
}
