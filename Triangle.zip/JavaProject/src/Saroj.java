public class Saroj {
	public static void main(String[] args) {
//		int [][] arr = {
//				{1,2,3},
//				{4,5,6,7,8,9},
//				{2,6,9}	
//		};
//		for (int i = 0; i < arr.length; i++) {
//			for (int j = 0; j < arr[i].length; j++) {
//				System.out.print(arr[i][j]);
//			}
//			System.out.println("\n*******");
//			System.out.println(arr[2][1]);
//
//		}

		String[][] fruits = { { "banana", "apple", "pear" }, { "grape", "cherry", "pineapple", "papaya" },
				{ "cheetos", "papaya", "rice", "totota", "matrix" } };

//			System.out.println(fruits[0][2]);

		for (int row = 0; row < fruits.length; row++) {
			for (int column = 0; column < fruits[row].length; column++) {
				System.out.print(" [" + fruits[row][column] + "] ");
			}
			System.out.println("\n================================================");
		}
		
		int height = 10;
		
		for(int i = 0; i < height; i++ ) {
			for (int j = 0; j < i; j++) {
				System.out.print("$");

			}
			System.out.println();
		}
		
//			
			}
		}

	

